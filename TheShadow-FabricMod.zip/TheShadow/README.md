# L'Ombra (The Shadow) — mod horror per Minecraft Fabric

Minecraft **26.3** · Fabric Loader 0.19.5+ · Fabric API · Java 25

Un'entità che scrive in chat come un giocatore vero, ti osserva, ti pedina e ti dà la caccia a ondate.

## Cosa fa
- **Chat**: `<L'Ombra> ...` con tono che cambia (amichevole finta → inquietante → aggressiva). Ricorda cosa hai fatto ("Ti ricordi quando sei morto cadendo? Io sì").
- **Reagisce a**: morte (frase diversa per causa), sonno (e ti guarda al risveglio), primo diamante, spawner (trovato e rotto).
- **Eventi horror** che crescono con le fasi: passi alle spalle, porte che si aprono, fulmine lontano + battito del cuore, finto "L'Ombra è entrato nel gioco" + il buio che si chiude, figura lontana che sparisce se la guardi, pedinamento (avanza solo quando non la guardi), agguato, isolamento (il mondo ammutolisce), eco nelle caverne, **jumpscare** (schermo che trema, titolo disturbato, urlo).
- **Fasi / ondate** (una sola volta per traguardo, salvate nel mondo):
  1. Sussurri (inizio) → 2. Pedinamento (12 min di gioco) → 3. **armatura di ferro completa** → 4. primo diamante → 5. Nether → 6. armatura di diamante completa → 7. armatura di netherite completa → 8. Ender Dragon sconfitto.
  In più: un'ondata a tempo ogni 15 minuti di gioco.
- **Come si uccide**: solo con la **spada di netherite** o con un'arma con **attacco > 8** (es. le asce). Le altre armi: "Quello non può uccidermi". Gli Echi (le sue ombre minori) muoiono con qualsiasi arma.
- **Combattimento**: preavviso prima dell'attacco forte (contorno luminoso + rumore), affondo, finestra di vulnerabilità, teletrasporto tattico, falsa sconfitta. Le ferite restano tra un'ondata e l'altra. Alla luce del giorno, all'aperto, si ritira.
- **8 indizi** sulla sua origine (`/ombra indizi`). Se li hai tutti quando la sconfiggi: finale segreto. Dopo la vittoria: `/ombra incubo`.

## Compilare con GitHub Actions (anche da telefono)
1. Nel repo, carica **TheShadow-FabricMod.zip** nella radice.
2. Metti il contenuto di **main.yml** in `.github/workflows/main.yml`.
3. Actions → *main* → *Run workflow*. A fine build scarica l'artifact **TheShadow-mod**: dentro c'è il `.jar`.
4. Copia il `.jar` + **Fabric API** nella cartella `mods` (Minecraft 26.3 con Fabric Loader).

Se la build dà errori, copia le righe `error:` del log.

In locale: Java 25 + Gradle 9.6 → `gradle build` (il jar è in `build/libs`). Le versioni sono in `gradle.properties`.

## Comandi (agiscono solo su chi li scrive)
`/ombra aiuto` · `stato` · `fase <1-8>` · `evento <sussurro|passi|porta|tuono|figura|eco|finto|pedinamento|isolamento|agguato|jumpscare>` · `onda` · `spawn` · `pulisci` · `indizi` · `reset` · `incubo`

## Impostazioni — `config/the_shadow.json`
`jumpscare` (false per toglierli), `jumpscareChance`, `screenShake`, `darkness`, `fakeJoin`, `doors`, `shadowBody`, `hostile` (false = non attacca mai), `speed` (0.5 eventi più rari, 2.0 più frequenti), `weaponThreshold` (8.0), `commands`, `enabled`.

Note: la soglia usa il valore di attacco del giocatore, quindi anche la Forza lo aumenta. In difficoltà Pacifica le Ombre non compaiono (restano chat e suoni). Progressi: `the_shadow.json` nella cartella del mondo.
