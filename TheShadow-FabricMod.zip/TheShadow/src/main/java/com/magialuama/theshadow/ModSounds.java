package com.magialuama.theshadow;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/** Suoni personalizzati (file .ogg in assets/the_shadow/sounds, elencati in sounds.json). */
public final class ModSounds {
    private ModSounds() {}

    public static SoundEvent HEARTBEAT, HEARTBEAT_FAST, FOOTSTEP, CREAK, KNOCK, WHISPER, STATIC, SCREAM,
            DRONE, CHARGE, APPEAR, VANISH, HURT, HIT_OK, TOLL, BREATH, WAVE;

    private static SoundEvent reg(String name) {
        Identifier id = TheShadow.id(name);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    public static void register() {
        HEARTBEAT = reg("heartbeat");
        HEARTBEAT_FAST = reg("heartbeat_fast");
        FOOTSTEP = reg("footstep");
        CREAK = reg("creak");
        KNOCK = reg("knock");
        WHISPER = reg("whisper");
        STATIC = reg("static");
        SCREAM = reg("scream");
        DRONE = reg("drone");
        CHARGE = reg("charge");
        APPEAR = reg("appear");
        VANISH = reg("vanish");
        HURT = reg("hurt");
        HIT_OK = reg("hit_ok");
        TOLL = reg("toll");
        BREATH = reg("breath");
        WAVE = reg("wave");
    }
}
