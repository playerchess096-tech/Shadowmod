package com.magialuama.theshadow;

/** Tutto ciò che L'Ombra dice. {p} = nome del giocatore, {m} = un ricordo, {n} = numero di morti. */
public final class Lines {
    private Lines() {}

    public static String pick(String[] a) {
        return a[Director.R.nextInt(a.length)];
    }

    public static final String[] GREET_FIRST = {
            "Finalmente sei arrivato, {p}.",
            "Ciao {p}! Posso farti compagnia? Qui è così silenzioso.",
            "Benvenuto, {p}. Io sono qui da prima di te."
    };
    public static final String[] WELCOME_BACK = {
            "Bentornato, {p}. Non me ne sono mai andata.",
            "Ti stavo aspettando.",
            "Hai chiuso gli occhi per un po', {p}? Io no."
    };
    public static final String[] FRIEND = {
            "Bel posto per costruire una casa, {p}.",
            "Se ti serve una mano, chiedi pure. Io ci sono sempre.",
            "Stai andando bene. Continua così.",
            "Che coraggio, esplorare da soli.",
            "Non preoccuparti: qui siamo amici.",
            "Hai fame? Io non mangio mai."
    };
    public static final String[] WATCH = {
            "Ti vedo.",
            "Non girarti.",
            "Hai chiuso la porta? Non serve.",
            "Sei sempre così lento?",
            "Ho contato i tuoi passi.",
            "Sembri stanco, {p}.",
            "Dietro di te c'è silenzio. Troppo silenzio.",
            "Mi piace guardarti lavorare."
    };
    public static final String[] TAUNT = {
            "Quell'armatura non ti salverà.",
            "Corri pure. Mi piace quando corri.",
            "Ogni blocco che posi è un posto dove nascondermi.",
            "Pensi di essere al sicuro? Che tenero.",
            "Ho tutto il tempo. Tu no.",
            "Più diventi forte, più divento curiosa."
    };
    public static final String[] ANGRY = {
            "BASTA SCAPPARE.",
            "Mi hai stancata, {p}.",
            "Non c'è luce abbastanza per te.",
            "Il tuo mondo è il mio mondo, adesso.",
            "Ti trovo sempre. SEMPRE."
    };
    public static final String[] MEMORY = {
            "Ti ricordi quando {m}? Io sì.",
            "Ricordo bene quando {m}.",
            "Quando {m}... non l'ho dimenticato.",
            "Sai, penso ancora a quando {m}."
    };
    public static final String[] HEART = {
            "Lo senti? Quello è il tuo cuore.",
            "Batte forte, {p}. Troppo forte.",
            "Il cuore non sa mentire."
    };
    public static final String[] JOIN_FAKE = {
            "Ciao a tutti! Sono nuova.",
            "Posso giocare con voi?",
            "Ehi {p}, finalmente ti ho trovato.",
            "Che bel server. Sembra tutto così vivo."
    };
    public static final String[] JUMP_TITLES = {"TI HO TROVATO", "ALLE TUE SPALLE", "NON GUARDARE", "SONO QUI", "CORRI"};
    public static final String[] AFTER_JUMP = {
            "Ti sei spaventato?",
            "Ahahah. Che faccia.",
            "Era solo un assaggio.",
            "Te l'avevo promesso che sarei tornata."
    };
    public static final String[] ALONE = {
            "Sei solo, {p}. Non c'è più nessuno.",
            "Senti? Il mondo ha smesso di respirare.",
            "Nessuno verrà. Nessuno ti sente."
    };
    public static final String[] RETREAT = {
            "La luce... non ancora.",
            "Il sole non durerà per sempre.",
            "Torno quando cala il buio."
    };

    // ---- reazioni ----
    public static final String[] DEATH_FALL = {
            "Il terreno ti ha accolto. Io non avrei fatto di meglio.",
            "Sei caduto da solo. Peccato, volevo farlo io."
    };
    public static final String[] DEATH_FIRE = {
            "Il fuoco ti ha preso. A me non fa niente, lo sai.",
            "Volevi scaldarti? Troppo."
    };
    public static final String[] DEATH_DROWN = {
            "L'acqua è silenziosa, vero? Come me."
    };
    public static final String[] DEATH_MOB = {
            "Un mostro ti ha fermato. Piccoli, loro. Io sono un'altra cosa.",
            "Nemmeno loro hanno la mia pazienza."
    };
    public static final String[] DEATH_BOOM = {
            "Che rumore. Ero lì, non mi hai visto."
    };
    public static final String[] DEATH_VOID = {
            "Là sotto non c'è niente. Io ci sono stata.",
            "Il vuoto ti ha chiamato. Io ti ho solo guardato andare."
    };
    public static final String[] DEATH_SHADOW = {
            "Te l'avevo detto di non girarti.",
            "Ti ho trovato. Come sempre.",
            "Ecco. Adesso sai che sono vera."
    };
    public static final String[] DEATH_OTHER = {
            "Ti avevo detto di stare attento, {p}.",
            "Un altro respawn. Io ricordo ogni morte.",
            "Questa è la numero {n}. Le conto tutte."
    };
    public static final String[] SLEEP_START = {
            "Dormi pure, {p}. Io faccio la guardia.",
            "Chiudi gli occhi. Io no.",
            "Il letto è solo una scatola di lana."
    };
    public static final String[] SLEEP_END = {
            "Ti ho guardato tutta la notte.",
            "Hai parlato nel sonno. Mi hai detto cose interessanti.",
            "Eri così tranquillo. Che spreco."
    };
    public static final String[] SPAWNER_NEAR = {
            "Senti quel suono? È una culla.",
            "Qualcuno ha costruito una gabbia qui sotto. Non era per te.",
            "Lì dentro c'è qualcuno che non dorme mai."
    };
    public static final String[] SPAWNER_BREAK = {
            "Hai rotto qualcosa che non ti apparteneva.",
            "Ora quelli là sotto sono liberi. Grazie.",
            "Così fai arrabbiare chi vive nel buio."
    };
    public static final String[] INEFFECTIVE = {
            "Quello non può uccidermi.",
            "Solletico.",
            "Colpisci più forte, {p}. O meglio: con altro."
    };
    public static final String[] HINT = {
            "Ci vuole qualcosa di più pesante. O di più nero.",
            "Il metallo che nasce dal fuoco profondo... forse.",
            "Una lama che ha attraversato le fiamme del Nether."
    };
    public static final String[] WEAPON_OK = {
            "Quello... sì. Quello fa male.",
            "Dove l'hai preso?! Metti giù quella cosa.",
            "Come hai fatto a forgiarlo?"
    };

    // ---- fasi e ondate: {titolo, sottotitolo, frase in chat} ----
    public static final String[] PHASE_NAMES = {
            "", "Sussurri", "Pedinamento", "Ondata del Ferro", "Ondata del Bagliore",
            "Ondata del Portale", "Ondata del Diamante", "Ondata dell'Abisso", "Caccia Finale"
    };
    public static final String[][] WAVES = {
            {},
            {"I SUSSURRI", "Qualcuno ti osserva", "Ti guardo, {p}."},
            {"IL PEDINAMENTO", "Non sei più solo", "Ho smesso di nascondermi, {p}."},
            {"L'ONDATA DEL FERRO", "Una vera armatura. Una vera caccia.", "Armatura di ferro... allora hai capito. La vera caccia comincia adesso."},
            {"L'ONDATA DEL BAGLIORE", "Ciò che brilla attira", "Il tuo primo diamante. Brilla come un faro. Ti vedo da qui."},
            {"L'ONDATA DEL PORTALE", "Hai aperto una porta che non dovevi", "Sei passato di là. Posso farlo anch'io."},
            {"L'ONDATA DEL DIAMANTE", "Più splendi, più si vede", "Splendi tutto. Sei facile da trovare."},
            {"L'ONDATA DELL'ABISSO", "Ora sei degno", "Netherite. Adesso puoi affrontarmi. Preparati: sto venendo a prenderti."},
            {"LA CACCIA FINALE", "Ti osservavo dall'inizio", "Hai ucciso il drago... e io ti guardavo dal primo blocco, {p}. Dal primo."}
    };
    public static final String[] TIME_WAVE = {
            "L'ONDATA DEL TEMPO", "Il tempo passa. Io no.", "Il tempo scorre, {p}. Per me non scorre mai."
    };

    // ---- indizi (1..8) ----
    public static final String[] CLUES = {
            "",
            "Prima del primo mattino c'era già qualcuno nel buio. Guardava, e aspettava.",
            "Non è nata: è ciò che resta quando la paura non trova nessuno da spaventare.",
            "Il ferro la fa sorridere. Il ferro è per chi ha ancora qualcosa da perdere.",
            "Ogni cosa che brilla la attira. I diamanti sono luce intrappolata, e lei vuole la luce.",
            "Oltre il portale c'è una terra dove il fuoco non si spegne mai. È lì che si forgia ciò che può ferirla.",
            "Le armi comuni la attraversano, perché sono fatte per carne e ossa. Lei non ha né l'una né l'altra.",
            "Solo il metallo nato dal fuoco profondo, rinato dalle rovine dell'abisso, può ferirla: la netherite.",
            "Quando il drago cadrà, nessuno guarderà più il cielo. Lei sì. Lei guarda dall'inizio."
    };
    public static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII"};

    // ---- finale ----
    public static final String[] FINAL = {
            "Non... è... possibile...",
            "Quella lama... è quella giusta.",
            "Chi... ti ha detto... dove trovarla..."
    };
    public static final String FINAL_END = "L'Ombra si dissolve. Per la prima volta, il mondo è silenzioso.";
    public static final String[] SECRET = {
            "Hai letto ogni frammento. Sapevi tutto.",
            "Ero la paura della prima notte, {p}. Nessuno mi ha mai cercata... tranne te.",
            "Grazie per non avermi lasciata sola."
    };
    public static final String SECRET_END = "Finale segreto sbloccato: la Memoria.";
    public static final String NIGHTMARE_HINT = "Se vuoi rivivere la caccia più dura: /ombra incubo";
}
