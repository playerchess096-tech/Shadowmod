package com.magialuama.theshadow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Impostazioni (config/the_shadow.json) e progressi dei giocatori (the_shadow.json nella cartella del mondo). */
public final class Data {
    private Data() {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Impostazioni modificabili a mano in config/the_shadow.json. */
    public static final class Config {
        public boolean enabled = true;          // interruttore generale
        public boolean chat = true;             // L'Ombra scrive in chat
        public boolean jumpscare = true;        // metti false per togliere i jumpscare
        public int jumpscareChance = 10;        // peso dei jumpscare tra gli eventi (0-100)
        public boolean screenShake = true;      // schermo che trema
        public boolean darkness = true;         // buio / cecità temporanei
        public boolean fakeJoin = true;         // finto "è entrato nel gioco"
        public boolean doors = true;            // porte che si aprono da sole
        public boolean shadowBody = true;       // il corpo dell'Ombra compare nel mondo
        public boolean hostile = true;          // l'Ombra può attaccarti
        public boolean commands = true;         // comandi /ombra disponibili
        public double speed = 1.0;              // 0.5 = eventi più rari, 2.0 = più frequenti
        public double weaponThreshold = 8.0;    // l'attacco deve superare questo valore (la spada di netherite vale sempre)
    }

    public static Config cfg = new Config();

    /** Progressi di un giocatore (salvati nel mondo). */
    public static final class PlayerData {
        public int phase = 1;
        public long playTicks = 0;
        public long nextTimeWaveAt = 0;
        public int deaths = 0;
        public int hits = 0;
        public double bossHp = 1.0;
        public boolean met = false;
        public boolean defeated = false;
        public boolean nightmare = false;
        public Set<String> flags = new LinkedHashSet<>();
        public Set<Integer> clues = new LinkedHashSet<>();
        public List<String> memory = new ArrayList<>();

        public boolean has(String f) { return flags.contains(f); }

        public void remember(String s) {
            memory.add(s);
            while (memory.size() > 10) memory.remove(0);
        }
    }

    private static final Map<UUID, PlayerData> PLAYERS = new HashMap<>();

    public static PlayerData of(UUID id) {
        return PLAYERS.computeIfAbsent(id, k -> new PlayerData());
    }

    public static void reset(UUID id) {
        PLAYERS.put(id, new PlayerData());
    }

    public static void loadConfig() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("the_shadow.json");
        try {
            if (Files.exists(p)) {
                Config c = GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), Config.class);
                if (c != null) cfg = c;
            }
            Files.writeString(p, GSON.toJson(cfg), StandardCharsets.UTF_8);
        } catch (Exception e) {
            TheShadow.LOG.warn("Config non leggibile, uso i valori predefiniti: {}", e.toString());
        }
    }

    private static Path file(MinecraftServer server) {
        return server.getWorldPath(LevelResource.ROOT).resolve("the_shadow.json");
    }

    public static void load(MinecraftServer server) {
        PLAYERS.clear();
        try {
            Path f = file(server);
            if (!Files.exists(f)) return;
            Type t = new TypeToken<Map<String, PlayerData>>() {}.getType();
            Map<String, PlayerData> m = GSON.fromJson(Files.readString(f, StandardCharsets.UTF_8), t);
            if (m != null) {
                for (Map.Entry<String, PlayerData> e : m.entrySet()) {
                    PLAYERS.put(UUID.fromString(e.getKey()), e.getValue());
                }
            }
        } catch (Exception e) {
            TheShadow.LOG.warn("Impossibile leggere i progressi: {}", e.toString());
        }
    }

    public static void save(MinecraftServer server) {
        try {
            Map<String, PlayerData> m = new HashMap<>();
            for (Map.Entry<UUID, PlayerData> e : PLAYERS.entrySet()) m.put(e.getKey().toString(), e.getValue());
            Files.writeString(file(server), GSON.toJson(m), StandardCharsets.UTF_8);
        } catch (Exception e) {
            TheShadow.LOG.warn("Impossibile salvare i progressi: {}", e.toString());
        }
    }
}
