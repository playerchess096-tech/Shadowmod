package com.magialuama.theshadow;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

import java.util.UUID;

/**
 * L'Ombra. Il comportamento vero e proprio vive in {@link Director#tickShadow}:
 * qui ci sono solo i dati di stato e gli attributi di base.
 */
public class ShadowEntity extends Monster {

    public enum Mode { OBSERVE, STALK, HUNT, JUMPSCARE }

    public UUID owner;                       // il giocatore che sta tormentando
    public Mode mode = Mode.OBSERVE;
    public boolean echo;                     // true = Eco (debole, muore con qualsiasi arma)
    public long expireTick;                  // quando sparisce da sola
    public int stare;                        // quanto a lungo è stata guardata
    public int stun;                         // finestra di vulnerabilità
    public int telegraph;                    // preavviso dell'attacco forte
    public int lunge;                        // durata dell'affondo
    public int blinkCooldown;
    public long nextBig;
    public boolean fakeDead;
    public boolean fakeDeadUsed;
    public long fakeDeadUntil;

    public ShadowEntity(EntityType<? extends ShadowEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setSilent(true); // i suoni li decide il Director
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 200.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.ATTACK_DAMAGE, 7.0D)
                .add(Attributes.FOLLOW_RANGE, 56.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.85D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15D, false));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level() instanceof ServerLevel serverLevel) {
            Director.tickShadow(this, serverLevel);
        }
    }
}
