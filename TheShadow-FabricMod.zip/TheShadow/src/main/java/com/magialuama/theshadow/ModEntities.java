package com.magialuama.theshadow;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

/** Registra l'entità "L'Ombra". */
public final class ModEntities {
    private ModEntities() {}

    public static final ResourceKey<EntityType<?>> SHADOW_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, TheShadow.id("shadow"));

    public static EntityType<ShadowEntity> SHADOW;

    public static void register() {
        SHADOW = Registry.register(BuiltInRegistries.ENTITY_TYPE, SHADOW_KEY,
                EntityType.Builder.of(ShadowEntity::new, MobCategory.MONSTER)
                        .sized(0.6F, 1.95F)
                        .clientTrackingRange(10)
                        .fireImmune()
                        .build(SHADOW_KEY));
        FabricDefaultAttributeRegistry.register(SHADOW, ShadowEntity.createAttributes());
    }
}
