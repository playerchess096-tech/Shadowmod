package com.magialuama.theshadow.client;

import com.magialuama.theshadow.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;

/** Lato client: collega l'entità al suo aspetto. */
public class TheShadowClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRenderers.register(ModEntities.SHADOW, ShadowRenderer::new);
    }
}
