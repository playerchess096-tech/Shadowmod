package com.magialuama.theshadow;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Punto d'ingresso della mod: registra suoni, entità, eventi e comandi. */
public class TheShadow implements ModInitializer {
    public static final String MOD_ID = "the_shadow";
    public static final Logger LOG = LoggerFactory.getLogger("TheShadow");

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        Data.loadConfig();
        ModSounds.register();
        ModEntities.register();
        Director.init();
        ShadowCommands.init();
        LOG.info("L'Ombra e' arrivata. Ti sta guardando.");
    }
}
