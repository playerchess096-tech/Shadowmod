package com.magialuama.theshadow;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** Comandi di prova: /ombra aiuto. Agiscono sempre e solo su chi li scrive. */
public final class ShadowCommands {
    private ShadowCommands() {}

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) -> dispatcher.register(root()));
    }

    private static void say(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal(text), false);
    }

    private static boolean enabled(CommandSourceStack src) {
        if (Data.cfg.commands) return true;
        src.sendFailure(Component.literal("I comandi sono disattivati in config/the_shadow.json"));
        return false;
    }

    private static LiteralArgumentBuilder<CommandSourceStack> root() {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("ombra");

        root.then(Commands.literal("aiuto").executes(c -> {
            say(c.getSource(), "/ombra stato | fase <1-8> | evento <nome> | onda | spawn | pulisci | indizi | reset | incubo");
            say(c.getSource(), "Eventi: " + String.join(", ", Director.EVENT_NAMES));
            return 1;
        }));

        root.then(Commands.literal("stato").executes(c -> {
            if (!enabled(c.getSource())) return 0;
            say(c.getSource(), Director.status(c.getSource().getPlayerOrException()));
            return 1;
        }));

        root.then(Commands.literal("fase").then(Commands.argument("n", IntegerArgumentType.integer(1, 8)).executes(c -> {
            if (!enabled(c.getSource())) return 0;
            ServerPlayer p = c.getSource().getPlayerOrException();
            Director.setPhase(p, IntegerArgumentType.getInteger(c, "n"));
            say(c.getSource(), Director.status(p));
            return 1;
        })));

        LiteralArgumentBuilder<CommandSourceStack> ev = Commands.literal("evento");
        for (String name : Director.EVENT_NAMES) {
            ev.then(Commands.literal(name).executes(c -> {
                if (!enabled(c.getSource())) return 0;
                ServerPlayer p = c.getSource().getPlayerOrException();
                if (!Director.force(p, name)) {
                    c.getSource().sendFailure(Component.literal("Evento non disponibile qui."));
                    return 0;
                }
                return 1;
            }));
        }
        root.then(ev);

        root.then(Commands.literal("onda").executes(c -> {
            if (!enabled(c.getSource())) return 0;
            return Director.forceWave(c.getSource().getPlayerOrException()) ? 1 : 0;
        }));

        root.then(Commands.literal("spawn").executes(c -> {
            if (!enabled(c.getSource())) return 0;
            if (!Director.spawnHunt(c.getSource().getPlayerOrException())) {
                c.getSource().sendFailure(Component.literal("Non posso farla comparire (difficoltà Pacifica o nessun posto libero)."));
                return 0;
            }
            return 1;
        }));

        root.then(Commands.literal("pulisci").executes(c -> {
            if (!enabled(c.getSource())) return 0;
            Director.clearShadows(c.getSource().getPlayerOrException().getUUID());
            say(c.getSource(), "Le Ombre sono sparite. Per ora.");
            return 1;
        }));

        root.then(Commands.literal("indizi").executes(c -> {
            if (!enabled(c.getSource())) return 0;
            for (String s : Director.clues(c.getSource().getPlayerOrException())) say(c.getSource(), s);
            return 1;
        }));

        root.then(Commands.literal("reset").executes(c -> {
            if (!enabled(c.getSource())) return 0;
            Director.reset(c.getSource().getPlayerOrException());
            say(c.getSource(), "I tuoi progressi con L'Ombra sono stati azzerati.");
            return 1;
        }));

        root.then(Commands.literal("incubo").executes(c -> {
            if (!enabled(c.getSource())) return 0;
            if (!Director.nightmare(c.getSource().getPlayerOrException())) {
                c.getSource().sendFailure(Component.literal("Prima devi sconfiggere L'Ombra."));
                return 0;
            }
            say(c.getSource(), "Modalità incubo attiva. La spada di netherite serve ancora.");
            return 1;
        }));

        return root;
    }
}
